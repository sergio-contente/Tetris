#pragma once
#ifndef DIRECTION_H
#define DIRECTION_H
enum class Direction {
    Left = 0, Right = 1, Down = 2, SoftDown = 3
};
#endif //DIRECTION_H
