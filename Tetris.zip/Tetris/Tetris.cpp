#include <SFML/Graphics.hpp>
#include <iostream>

#include "Game.h"

using namespace sf;

int main()
{
    Game game;
    game.Run();

    return 0;
}